import javax.swing.*;
import java.awt.*;

public class Eventos extends JFrame{
    public Eventos(){
        setTitle("DUNAB - Encuentros/Eventos");
        setSize(900, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Panel gradiente
        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(0, 0, 102);
                Color color2 = new Color(0, 153, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setLayout(null);
        setContentPane(gradientPanel);

        // ICONOS
        ImageIcon dineroIcon = new ImageIcon("icons/dinero.png");
        ImageIcon perfilIcon = new ImageIcon("icons/perfil.png");

        // Escala íconos
        Image dineroImg = dineroIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
        Image perfilImg = perfilIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);

        // Barra superior
        JPanel topBar = new JPanel();
        topBar.setLayout(null);
        topBar.setBounds(0, 0, 900, 50);
        topBar.setBackground(new Color(0, 90, 255));
        gradientPanel.add(topBar);

        JButton title = new JButton("DUNAB");
        title.setFont(new Font("SansSerif", Font.BOLD, 15));
        title.setForeground(new Color(0, 90, 255));
        title.setBounds(20, 10, 100, 30);
        topBar.add(title);
        title.addActionListener(e -> new DunabInicio("admin").setVisible(true));

        JLabel moneyIcon = new JLabel(new ImageIcon(dineroIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        moneyIcon.setBounds(120, 8, 40, 40);
        topBar.add(moneyIcon);

        JLabel perfilTop = new JLabel(new ImageIcon(perfilIcon.getImage().getScaledInstance(28, 28, Image.SCALE_SMOOTH)));
        perfilTop.setBounds(840, 10, 40, 40);
        topBar.add(perfilTop);

        // Texto principal
        JLabel eventos = new JLabel("Encuentros/Eventos", SwingConstants.LEFT);
        eventos.setFont(new Font("SansSerif", Font.BOLD, 25));
        eventos.setForeground(Color.WHITE);
        eventos.setBounds(0, 60, 900, 50);
        gradientPanel.add(eventos);

        // Panel de eventos
        int plax = 50;
        int play = 130;
        for (int i=1; i<=6; i++){
            String[] evento = {"Taller de salsa", "8-9am - 22 Octubre", "Recibes 205 Dunab"};
            String tit = "Evento " + i;
            JPanel panelEvento = crearPanelBlanco(tit, evento);
            panelEvento.setBounds(plax, play, 150, 100);
            gradientPanel.add(panelEvento);
            if (i<=2){
                plax = plax + 300;
            }else if (i==3){
                plax = 50;
                play = 300;
            }else{
                plax = plax +300;
            }
        }
    }

    private JPanel crearPanelBlanco(String titulo, String[] datos) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(titulo));
        for (String dato : datos) {
            JLabel label = new JLabel(dato);
            label.setFont(new Font("SansSerif", Font.PLAIN, 14));
            label.setAlignmentX(Component.CENTER_ALIGNMENT);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(label);
        }
        panel.setMaximumSize(new Dimension(450, panel.getPreferredSize().height));
        return panel;
    }
}
