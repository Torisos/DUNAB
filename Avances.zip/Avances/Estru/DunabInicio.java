import javax.swing.*;
import java.awt.*;

public class DunabInicio extends JFrame {
    private String usuario;

    public DunabInicio(String usuario) {
        this.usuario = usuario;
        setTitle("DUNAB - Inicio");
        setSize(900, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Panel gradiente
        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color c1 = new Color(0, 0, 120);
                Color c2 = new Color(0, 80, 200);
                GradientPaint gp = new GradientPaint(0, 0, c1, 0, getHeight(), c2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setLayout(null);
        setContentPane(gradientPanel);
        
        // ICONOS
        ImageIcon dineroIcon = new ImageIcon("icons/dinero.png");
        ImageIcon perfilIcon = new ImageIcon("icons/perfil.png");
        ImageIcon trofeoIcon = new ImageIcon("icons/trofeo.png");

        // Barra superior
        JPanel topBar = new JPanel();
        topBar.setLayout(null);
        topBar.setBounds(0, 0, 900, 50);
        topBar.setBackground(new Color(0, 90, 255));
        gradientPanel.add(topBar);

        JLabel title = new JLabel("DUNAB");
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        title.setBounds(20, 10, 200, 30);
        topBar.add(title);

        JButton soporte = new JButton("Soporte");
        soporte.setFont(new Font("SansSerif", Font.BOLD, 15));
        soporte.setForeground(new Color(0, 90, 255));
        soporte.setBounds(120, 10, 100, 30);
        topBar.add(soporte);
        soporte.addActionListener(e -> new Soporte().setVisible(true));

        JLabel moneyIcon = new JLabel(new ImageIcon(dineroIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        moneyIcon.setBounds(220, 8, 40, 40);
        topBar.add(moneyIcon);

        JLabel perfilTop = new JLabel(new ImageIcon(perfilIcon.getImage().getScaledInstance(28, 28, Image.SCALE_SMOOTH)));
        perfilTop.setBounds(840, 10, 40, 40);
        topBar.add(perfilTop);

        // Texto principal
        JLabel saldo = new JLabel("Saldo Actual", SwingConstants.CENTER);
        saldo.setFont(new Font("SansSerif", Font.BOLD, 40));
        saldo.setForeground(Color.WHITE);
        saldo.setBounds(0, 80, 900, 50);
        gradientPanel.add(saldo);

        JLabel valor = new JLabel("5.000 DUNAB", SwingConstants.CENTER);
        valor.setFont(new Font("SansSerif", Font.BOLD, 28));
        valor.setForeground(Color.WHITE);
        valor.setBounds(0, 130, 900, 50);
        gradientPanel.add(valor);

        // ICONOS de cada botón
        ImageIcon iconHistorial = new ImageIcon("icons/transacciones.png");
        ImageIcon iconPromedios = new ImageIcon("icons/promedios.png");
        ImageIcon iconEventos = new ImageIcon("icons/eventos.png");
        ImageIcon iconPerfil = new ImageIcon("icons/perfil.png");

        // Botones con iconos y texto
        JButton btnHistorial = new JButton("Historial",
            new ImageIcon(iconHistorial.getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH)));
        btnHistorial.setBounds(100, 220, 170, 130); // posición y tamaño

        JButton btnPromedios = new JButton("Promedios",
            new ImageIcon(iconPromedios.getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH)));
        btnPromedios.setBounds(300, 220, 170, 130);

        JButton btnEventos = new JButton("Eventos",
            new ImageIcon(iconEventos.getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH)));
        btnEventos.setBounds(500, 220, 170, 130);

        JButton btnPerfil = new JButton("Perfil",
            new ImageIcon(iconPerfil.getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH)));
        btnPerfil.setBounds(700, 220, 170, 130);

        // Mensaje inferior
        JButton logro = new JButton("¡Has alcanzado 5.000 DUNAB!", 
        new ImageIcon(trofeoIcon.getImage().getScaledInstance(35, 35, Image.SCALE_SMOOTH)));
        logro.setBounds(285, 400, 350, 40);
        logro.setOpaque(true);
        logro.setBackground(new Color(40, 90, 255));
        logro.setForeground(Color.WHITE);
        logro.setFont(new Font("SansSerif", Font.BOLD, 16));
        gradientPanel.add(logro);

        // Botón administración (solo para admin)
        if ("admin".equalsIgnoreCase(usuario)) {
            JButton adminBtn = new JButton("Administración");
            adminBtn.setFont(new Font("SansSerif", Font.BOLD, 15));
            adminBtn.setForeground(new Color(0, 90, 255));
            adminBtn.setBounds(720, 10, 120, 30);
            topBar.add(adminBtn);

            adminBtn.addActionListener(e -> new AdminDashboard(usuario).setVisible(true));
        }
        
        // Acciones de los botones → cambiar panel
        btnHistorial.addActionListener(e -> new HistorialTrans(usuario).setVisible(true));
        btnEventos.addActionListener(e -> new Eventos().setVisible(true));
        btnPerfil.addActionListener(e -> new DunabPerfil().setVisible(true));
        logro.addActionListener(e -> new Logro(usuario).setVisible(true));

        gradientPanel.add(btnHistorial);
        gradientPanel.add(btnPromedios);
        gradientPanel.add(btnEventos);
        gradientPanel.add(btnPerfil);
    }
}
