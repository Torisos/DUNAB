import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

public class Logro extends JFrame{
    private String usuario;       // usuario actual
    private int dunabActual = 0;  // saldo leído del archivo
    private Map<String, Integer> ranking; 

    public Logro(String usuario){
        this.usuario = usuario;
        this.dunabActual = leerSaldoUsuario(usuario);

        setTitle("DUNAB - Logro");
        setSize(900, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Panel gradiente
        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color c1 = new Color(0, 0, 120);
                Color c2 = new Color(0, 80, 200);
                GradientPaint gp = new GradientPaint(0, 0, c1, 0, getHeight(), c2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setLayout(null);
        setContentPane(gradientPanel);

        // ICONOS
        ImageIcon dineroIcon = new ImageIcon("icons/dinero.png");
        ImageIcon perfilIcon = new ImageIcon("icons/perfil.png");
        ImageIcon trofeoIcon = new ImageIcon("icons/trofeo.png");

        // Barra superior
        JPanel topBar = new JPanel();
        topBar.setLayout(null);
        topBar.setBounds(0, 0, 900, 50);
        topBar.setBackground(new Color(0, 90, 255));
        gradientPanel.add(topBar);

        JButton title = new JButton("DUNAB");
        title.setFont(new Font("SansSerif", Font.BOLD, 15));
        title.setForeground(new Color(0, 90, 255));
        title.setBounds(20, 10, 100, 30);
        topBar.add(title);
        title.addActionListener(e -> new DunabInicio("admin").setVisible(true));

        JLabel moneyIcon = new JLabel(new ImageIcon(dineroIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        moneyIcon.setBounds(120, 8, 40, 40);
        topBar.add(moneyIcon);

        JLabel perfilTop = new JLabel(new ImageIcon(perfilIcon.getImage().getScaledInstance(28, 28, Image.SCALE_SMOOTH)));
        perfilTop.setBounds(840, 10, 40, 40);
        topBar.add(perfilTop);

        // Mostrar saldo actual
        JLabel saldoLabel = new JLabel("Saldo actual: " + dunabActual + " DUNAB", SwingConstants.CENTER);
        saldoLabel.setFont(new Font("SansSerif", Font.BOLD, 28));
        saldoLabel.setForeground(Color.WHITE);
        saldoLabel.setBounds(0, 80, 900, 40);
        gradientPanel.add(saldoLabel);

        // 🔹 Notificaciones automáticas
        if (dunabActual >= 5000 && dunabActual < 10000) {
            mostrarNotificacion("¡Felicitaciones! Has alcanzado 5000 DUNAB 🎉");
        } else if (dunabActual >= 10000) {
            mostrarNotificacion("¡Increíble! Has alcanzado 10000 DUNAB 🏆");
        }

        // 🔹 Conversión de DUNAB a puntos estudiantiles
        JButton convertirBtn = new JButton("Convertir a Beneficios");
        convertirBtn.setBounds(350, 150, 200, 40);
        gradientPanel.add(convertirBtn);

        JLabel conversionLabel = new JLabel("", SwingConstants.CENTER);
        conversionLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        conversionLabel.setForeground(Color.WHITE);
        conversionLabel.setBounds(0, 200, 900, 40);
        gradientPanel.add(conversionLabel);

        convertirBtn.addActionListener(e -> {
            int puntos = convertirADerechos(dunabActual);
            conversionLabel.setText("Equivale a " + puntos + " puntos de beneficios estudiantiles 🎓");
        });

        // 🔹 Ranking de estudiantes
        JPanel rankingPanel = construirRankingPanel();
        gradientPanel.add(rankingPanel);

    }
    // Método para mostrar notificaciones
    private void mostrarNotificacion(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Notificación", JOptionPane.INFORMATION_MESSAGE);
    }

    // Conversión de DUNAB a puntos estudiantiles (ejemplo: 1 DUNAB = 0.1 puntos)
    private int convertirADerechos(int dunab) {
        return dunab / 10;
    }

    // 🔹 Leer saldo del usuario desde archivo usuarios.txt
    private int leerSaldoUsuario(String usuario) {
        try (BufferedReader br = new BufferedReader(new FileReader("Estru/usuarios.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 4) {
                    String user = partes[0].trim();
                    int saldo = Integer.parseInt(partes[3].trim());
                    if (user.equals(usuario)) {
                        return saldo;
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error leyendo archivo de usuarios", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return 0;
    }

    private JPanel construirRankingPanel() {
    // Lista tipada correctamente
    List<Map.Entry<String, Integer>> lista = new ArrayList<>();

    try (BufferedReader br = new BufferedReader(new FileReader("Estru/usuarios.txt"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] partes = linea.split(";");
            if (partes.length == 4) {
                String user = partes[0].trim();
                String puntosStr = partes[3].trim()
                        .replace(".", "")
                        .replace(",", "");
                try {
                    int saldo = Integer.parseInt(puntosStr);
                    lista.add(new AbstractMap.SimpleEntry<>(user, saldo));
                } catch (NumberFormatException ignore) {
                    // Línea mal formateada: la saltamos
                }
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error leyendo ranking", "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Ordenar de mayor a menor (sin method reference para evitar ambigüedad de tipos)
    lista.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

    // Construir panel visual
    JPanel rankingPanel = new JPanel();
    rankingPanel.setLayout(new BoxLayout(rankingPanel, BoxLayout.Y_AXIS));
    rankingPanel.setBackground(Color.WHITE);
    rankingPanel.setBorder(BorderFactory.createTitledBorder("Ranking de Estudiantes"));
    rankingPanel.setBounds(250, 260, 400, 200);

    for (Map.Entry<String, Integer> entry : lista) {
        JLabel label = new JLabel(entry.getKey() + " - " + entry.getValue() + " DUNAB");
        label.setFont(new Font("SansSerif", Font.PLAIN, 16));
        rankingPanel.add(label);
    }

    return rankingPanel;
}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Logro("admin").setVisible(true);
            });
    }
}