import javax.swing.*;
import java.awt.*;

public class DunabPerfil extends JFrame {

    public DunabPerfil() {
        setTitle("DUNAB - Perfil");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Fondo
        JPanel fondo = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(0, 0, 120), 0, getHeight(), new Color(0, 80, 200));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        fondo.setLayout(new BorderLayout());
        setContentPane(fondo);

        // ICONOS
        ImageIcon dineroIcon = new ImageIcon("icons/dinero.png");
        ImageIcon perfilIcon = new ImageIcon("icons/perfil.png");

        // Barra superior
        JPanel topBar = new JPanel();
        topBar.setLayout(null);
        topBar.setBounds(0, 0, 1000, 50);
        topBar.setBackground(new Color(0, 90, 255));
        fondo.add(topBar);

        JButton title = new JButton("DUNAB");
        title.setFont(new Font("SansSerif", Font.BOLD, 15));
        title.setForeground(new Color(0, 90, 255));
        title.setBounds(20, 10, 100, 30);
        topBar.add(title);
        title.addActionListener(e -> new DunabInicio("admin").setVisible(true));

        JLabel moneyIcon = new JLabel(new ImageIcon(dineroIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        moneyIcon.setBounds(120, 8, 40, 40);
        topBar.add(moneyIcon);

        JLabel perfilTop = new JLabel(new ImageIcon(perfilIcon.getImage().getScaledInstance(28, 28, Image.SCALE_SMOOTH)));
        perfilTop.setBounds(840, 10, 40, 40);
        topBar.add(perfilTop);

        // Panel izquierdo - Eventos
        JPanel eventosPanel = new JPanel();
        eventosPanel.setPreferredSize(new Dimension(250, 0));
        eventosPanel.setBackground(new Color(0, 0, 100));
        eventosPanel.setLayout(new BoxLayout(eventosPanel, BoxLayout.Y_AXIS));
        JLabel eventosLabel = new JLabel("Eventos Asistidos:");
        eventosLabel.setForeground(Color.WHITE);
        eventosLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        eventosPanel.add(eventosLabel);
        for (int i = 0; i < 5; i++) {
            JLabel evento = new JLabel("Cultural");
            evento.setForeground(Color.WHITE);
            eventosPanel.add(evento);
        }

        // Panel central - Información personal y académica
        JPanel centroPanel = new JPanel();
        centroPanel.setOpaque(false);
        centroPanel.setLayout(new BoxLayout(centroPanel, BoxLayout.Y_AXIS));
        centroPanel.add(Box.createVerticalStrut(100));
        centroPanel.add(crearPanelBlanco("Información Personal", new String[]{
            "Nombre: NICOLÁS EDUARDO DUARTE SANJUÁN",
            "Email: nduarte513@unab.edu.co",
            "CC: 1099621547"
        }));
        centroPanel.add(Box.createVerticalStrut(170));
        centroPanel.add(crearPanelBlanco("Información Académica", new String[]{
            "ID: 100771237",
            "Programa: Ingeniería de Sistemas",
            "Último período: 202650",
            "Rol: Estudiante"
        }));

        centroPanel.add(Box.createVerticalStrut(100));
        centroPanel.add(Box.createVerticalStrut(100));

        // Panel derecho - Saldo
        JPanel saldoPanel = new JPanel();
        saldoPanel.setMaximumSize(new Dimension(200, 100)); 
        saldoPanel.setPreferredSize(new Dimension(170, 0));
        saldoPanel.setBackground(Color.WHITE);
        saldoPanel.setLayout(new BoxLayout(saldoPanel, BoxLayout.Y_AXIS));
        saldoPanel.setBorder(BorderFactory.createTitledBorder("Saldo de la cuenta"));
        JLabel saldoValor = new JLabel("5.000 DUNAB");
        saldoValor.setFont(new Font("SansSerif", Font.BOLD, 18));
        saldoValor.setAlignmentX(Component.CENTER_ALIGNMENT);
        saldoPanel.add(Box.createVerticalGlue());
        saldoPanel.add(saldoValor);
        saldoPanel.add(Box.createVerticalGlue());

        // Agregar paneles al layout principal
        fondo.add(eventosPanel, BorderLayout.WEST);
        fondo.add(centroPanel, BorderLayout.CENTER);
        fondo.add(saldoPanel, BorderLayout.EAST);
    }

    private JPanel crearPanelBlanco(String titulo, String[] datos) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(titulo));
        for (String dato : datos) {
            JLabel label = new JLabel(dato);
            label.setFont(new Font("SansSerif", Font.PLAIN, 14));
            label.setAlignmentX(Component.CENTER_ALIGNMENT);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(label);
        }
        panel.setMaximumSize(new Dimension(450, panel.getPreferredSize().height));
        return panel;
    }
}