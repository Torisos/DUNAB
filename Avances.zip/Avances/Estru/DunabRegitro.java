import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Random;

public class DunabRegitro extends JFrame{
    
    public DunabRegitro() {
        Random rand = new Random();
        int puntos = rand.nextInt(15000);
        setTitle("Dunab - Registro");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Panel gradiente
        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(0, 0, 102);
                Color color2 = new Color(0, 153, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setLayout(null);
        setContentPane(gradientPanel);

        // Carga iconos
        ImageIcon perfilIcon = new ImageIcon("icons/perfil.png");
        ImageIcon callIcon = new ImageIcon("icons/call.png");
        ImageIcon contraseñaIcon = new ImageIcon("icons/contraseña.png");

        // Escala íconos si son grandes
        Image perfilImg = perfilIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
        Image callImg = callIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
        Image contraseñaImg = contraseñaIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);

        // Tit
        JLabel title = new JLabel("Registrate", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 28));
        title.setForeground(Color.WHITE);
        title.setBounds(100, 30, 200, 40);
        gradientPanel.add(title);

        // Perfil
        JLabel userIcon = new JLabel(new ImageIcon(perfilImg));
        userIcon.setBounds(20, 125, 25, 25);
        gradientPanel.add(userIcon);
        JTextField perfilField = new JTextField();
        perfilField.setBounds(50, 125, 300, 30);
        gradientPanel.add(perfilField);

        // Call
        JLabel numberIcon = new JLabel(new ImageIcon(callImg));
        numberIcon.setBounds(20, 175, 25, 25);
        gradientPanel.add(numberIcon);
        JTextField callField = new JTextField();
        callField.setBounds(50, 175, 300, 30);
        gradientPanel.add(callField);

        // Contraseñas
        JLabel primContraseñaIcon = new JLabel(new ImageIcon(contraseñaImg));
        primContraseñaIcon.setBounds(20, 225, 25, 25);
        gradientPanel.add(primContraseñaIcon);
        JTextField contraseña1Field = new JTextField();
        contraseña1Field.setBounds(50, 225, 300, 30);
        gradientPanel.add(contraseña1Field);

        JLabel segunContraseñaIcon = new JLabel(new ImageIcon(contraseñaImg));
        segunContraseñaIcon.setBounds(20, 275, 25, 25);
        gradientPanel.add(segunContraseñaIcon);
        JTextField contraseña2Field = new JTextField();
        contraseña2Field.setBounds(50, 275, 300, 30);
        gradientPanel.add(contraseña2Field);

        // Botónes
        JButton crearButton = new JButton("Crear");
        crearButton.setBounds(125, 325, 150, 35);
        gradientPanel.add(crearButton);

        JButton cancelarButton = new JButton("Cancelar");
        cancelarButton.setBounds(125, 375, 150, 35);
        gradientPanel.add(cancelarButton);
        cancelarButton.addActionListener(e -> new DunabLogin().setVisible(true));

        // Acción del botón Crear
        crearButton.addActionListener(e -> {
            String usuario = perfilField.getText().trim();
            String telefono = callField.getText().trim();
            String pass1 = contraseña1Field.getText().trim();
            String pass2 = contraseña2Field.getText().trim();

            if (usuario.isEmpty() || telefono.isEmpty() || pass1.isEmpty() || pass2.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor llena todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!pass1.equals(pass2)) {
                JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (FileWriter fw = new FileWriter("Estru/usuarios.txt", true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {
                
                // Guardamos en formato usuario;telefono;contraseña
                out.println("\n" + usuario + ";" + telefono + ";" + pass1 + ";" + puntos);
                JOptionPane.showMessageDialog(this, "Usuario creado exitosamente!");
                
                // Limpiar campos
                perfilField.setText("");
                callField.setText("");
                contraseña1Field.setText("");
                contraseña2Field.setText("");

                SwingUtilities.invokeLater(() -> {
                new DunabLogin().setVisible(true);
                });
                
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar usuario", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}