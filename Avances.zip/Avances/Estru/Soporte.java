import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List; 

public class Soporte extends JFrame{
    private DefaultListModel<String> preguntasModel;
    private JList<String> preguntasList;
    private JTextArea respuestaArea;
    private JTextField buscarField;

    // Base de conocimiento simple en memoria (puedes luego leerla de FAQs.txt)
    private List<FAQ> baseFaqs = new ArrayList<>();

    public Soporte(){
        setTitle("DUNAB - Soporte");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel gradiente
        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color c1 = new Color(0, 0, 120);
                Color c2 = new Color(0, 80, 200);
                GradientPaint gp = new GradientPaint(0, 0, c1, 0, getHeight(), c2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setLayout(null);
        setContentPane(gradientPanel);

        // ICONOS
        ImageIcon dineroIcon = new ImageIcon("icons/dinero.png");
        ImageIcon perfilIcon = new ImageIcon("icons/perfil.png");

        // Barra superior
        JPanel topBar = new JPanel();
        topBar.setLayout(null);
        topBar.setBounds(0, 0, 1000, 50);
        topBar.setBackground(new Color(0, 90, 255));
        gradientPanel.add(topBar);

        JButton title = new JButton("DUNAB");
        title.setFont(new Font("SansSerif", Font.BOLD, 15));
        title.setForeground(new Color(0, 90, 255));
        title.setBounds(20, 10, 100, 30);
        topBar.add(title);
        title.addActionListener(e -> new DunabInicio("admin").setVisible(true));

        JLabel moneyIcon = new JLabel(new ImageIcon(dineroIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        moneyIcon.setBounds(120, 8, 40, 40);
        topBar.add(moneyIcon);

        JLabel perfilTop = new JLabel(new ImageIcon(perfilIcon.getImage().getScaledInstance(28, 28, Image.SCALE_SMOOTH)));
        perfilTop.setBounds(940, 10, 40, 40);
        topBar.add(perfilTop);

        // Contenedor principal
        JPanel contenido = new JPanel(null);
        contenido.setOpaque(false);
        contenido.setBounds(20, 70, 960, 480);
        gradientPanel.add(contenido);

        // Campo de búsqueda
        buscarField = new JTextField();
        buscarField.setBounds(20, 10, 300, 30);
        contenido.add(buscarField);

        JButton buscarBtn = new JButton("Buscar");
        buscarBtn.setBounds(330, 10, 90, 30);
        contenido.add(buscarBtn);

        // Botón contactar soporte
        JButton contactarBtn = new JButton("Contactar soporte");
        contactarBtn.setBounds(440, 10, 160, 30);
        contenido.add(contactarBtn);

        // Lista de preguntas
        preguntasModel = new DefaultListModel<>();
        preguntasList = new JList<>(preguntasModel);
        preguntasList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        preguntasList.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JScrollPane preguntasScroll = new JScrollPane(preguntasList);
        preguntasScroll.setBounds(20, 60, 350, 390);
        preguntasScroll.setBorder(BorderFactory.createTitledBorder("Preguntas frecuentes"));
        contenido.add(preguntasScroll);

        // Área de respuesta
        respuestaArea = new JTextArea();
        respuestaArea.setEditable(false);
        respuestaArea.setLineWrap(true);
        respuestaArea.setWrapStyleWord(true);
        respuestaArea.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JScrollPane respuestaScroll = new JScrollPane(respuestaArea);
        respuestaScroll.setBounds(390, 60, 550, 390);
        respuestaScroll.setBorder(BorderFactory.createTitledBorder("Respuesta"));
        contenido.add(respuestaScroll);

        // Carga de FAQs y eventos
        cargarBaseFaqs();
        poblarPreguntas(baseFaqs);

        preguntasList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int idx = preguntasList.getSelectedIndex();
                if (idx >= 0) {
                    String pregunta = preguntasModel.getElementAt(idx);
                    // Buscar respuesta correspondiente
                    for (FAQ faq : baseFaqs) {
                        if (faq.pregunta.equals(pregunta)) {
                            respuestaArea.setText(formatearRespuesta(faq));
                            break;
                        }
                    }
                }
            }
        });

        buscarBtn.addActionListener(e -> {
            String q = buscarField.getText().trim().toLowerCase();
            if (q.isEmpty()) {
                poblarPreguntas(baseFaqs);
                respuestaArea.setText("");
                return;
            }
            List<FAQ> filtradas = new ArrayList<>();
            for (FAQ faq : baseFaqs) {
                if (faq.pregunta.toLowerCase().contains(q) || faq.respuesta.toLowerCase().contains(q)) {
                    filtradas.add(faq);
                }
            }
            poblarPreguntas(filtradas);
            respuestaArea.setText("");
        });

        contactarBtn.addActionListener(e -> abrirDialogoContacto());
    }

    // --------- Utilidades del módulo ---------

    private void cargarBaseFaqs() {
        baseFaqs.clear();
        baseFaqs.add(new FAQ(
                "¿Cómo inicio sesión en DUNAB?",
                "Ve a la pantalla de login, ingresa tu correo y contraseña registrados. Si olvidaste tu contraseña, usa la opción 'Recuperar'."
        ));
        baseFaqs.add(new FAQ(
                "¿Cómo consulto mi saldo DUNAB?",
                "Desde Inicio verás tu saldo. También puedes actualizarlo entrando a Perfil o realizando una transacción válida."
        ));
        baseFaqs.add(new FAQ(
                "¿Cómo convierto DUNAB a beneficios estudiantiles?",
                "En el módulo Logros, presiona 'Convertir a Beneficios'. Se aplica la tasa definida por tu institución. Verás los puntos equivalentes."
        ));
        baseFaqs.add(new FAQ(
                "¿Cómo funciona el ranking de estudiantes?",
                "El ranking se calcula con los DUNAB acumulados por cada usuario y se ordena de mayor a menor. Se actualiza al registrar cambios en usuarios.txt."
        ));
        baseFaqs.add(new FAQ(
                "No veo mis transacciones en Historial",
                "Verifica que Trans.txt tenga el formato usuario;fecha;tipo;detalle y que estés logueado con el usuario correcto. Usa el botón 'Añadir' para crear nuevas entradas."
        ));
        baseFaqs.add(new FAQ(
                "¿Cómo reporto un problema?",
                "Usa el botón 'Contactar soporte', describe el problema con detalle y adjunta capturas si es posible. Te daremos respuesta pronto."
        ));
    }

    private void poblarPreguntas(List<FAQ> faqs) {
        preguntasModel.clear();
        for (FAQ faq : faqs) {
            preguntasModel.addElement(faq.pregunta);
        }
        if (!faqs.isEmpty()) {
            preguntasList.setSelectedIndex(0);
        }
    }

    private String formatearRespuesta(FAQ faq) {
        StringBuilder sb = new StringBuilder();
        sb.append(faq.pregunta).append("\n\n");
        sb.append(faq.respuesta).append("\n");
        return sb.toString();
    }

    private void abrirDialogoContacto() {
        JDialog dialog = new JDialog(this, "Contactar soporte", true);
        dialog.setSize(500, 380);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(null);

        JLabel asuntoLbl = new JLabel("Asunto:");
        asuntoLbl.setBounds(20, 20, 100, 25);
        dialog.add(asuntoLbl);

        JTextField asuntoField = new JTextField();
        asuntoField.setBounds(120, 20, 340, 25);
        dialog.add(asuntoField);

        JLabel mensajeLbl = new JLabel("Mensaje:");
        mensajeLbl.setBounds(20, 60, 100, 25);
        dialog.add(mensajeLbl);

        JTextArea mensajeArea = new JTextArea();
        mensajeArea.setLineWrap(true);
        mensajeArea.setWrapStyleWord(true);
        JScrollPane msgScroll = new JScrollPane(mensajeArea);
        msgScroll.setBounds(120, 60, 340, 180);
        dialog.add(msgScroll);

        JButton enviarBtn = new JButton("Enviar");
        enviarBtn.setBounds(280, 260, 90, 30);
        dialog.add(enviarBtn);

        JButton cancelarBtn = new JButton("Cancelar");
        cancelarBtn.setBounds(370, 260, 90, 30);
        dialog.add(cancelarBtn);

        enviarBtn.addActionListener(e -> {
            String asunto = asuntoField.getText().trim();
            String mensaje = mensajeArea.getText().trim();
            if (asunto.isEmpty() || mensaje.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Por favor completa asunto y mensaje.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            // Aquí podrías guardar en soporte.txt o enviar a un backend
            // Ejemplo simple: guardar en archivo local
            try (PrintWriter pw = new PrintWriter(new FileWriter("soporte.txt", true))) {
                pw.println("Asunto: " + asunto);
                pw.println("Mensaje: " + mensaje);
                pw.println("-----");
                JOptionPane.showMessageDialog(dialog, "Tu solicitud fue enviada. ¡Gracias!");
                dialog.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error al enviar soporte.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelarBtn.addActionListener(e -> dialog.dispose());
        dialog.setVisible(true);
    }

    // Estructura simple para FAQ
    private static class FAQ {
        String pregunta;
        String respuesta;
        FAQ(String p, String r) { this.pregunta = p; this.respuesta = r; }
    }
}