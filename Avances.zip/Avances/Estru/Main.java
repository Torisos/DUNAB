import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main {
    public static void main (String[] args){
        String[] opciones = {"Iniciar sesión", "Crear cuenta"};

        int seleccion = JOptionPane.showOptionDialog(
                null,
                "¿Qué deseas hacer?",
                "DUNAB - Opciones",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[0]
        );

        if (seleccion == 0) {
            SwingUtilities.invokeLater(() -> {
            new DunabLogin().setVisible(true);
            });
        } else if (seleccion == 1) {
            SwingUtilities.invokeLater(() -> {
            new DunabRegitro().setVisible(true);
            });
        } else {
            JOptionPane.showMessageDialog(null, "No seleccionaste ninguna opción");
        }
    }
}