import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class DunabLogin extends JFrame {

    public DunabLogin() {
        setTitle("Dunab");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Panel gradiente
        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(0, 0, 102);
                Color color2 = new Color(0, 153, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setLayout(null);
        setContentPane(gradientPanel);

        // Carga iconos
        ImageIcon googleIcon = new ImageIcon("icons/google.png");
        ImageIcon githubIcon = new ImageIcon("icons/github.png");
        ImageIcon facebookIcon = new ImageIcon("icons/facebook.png");

        // Tit
        JLabel title = new JLabel("Dunab", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 28));
        title.setForeground(Color.WHITE);
        title.setBounds(100, 30, 200, 40);
        gradientPanel.add(title);

        // Email
        JLabel email = new JLabel("Email");
        email.setFont(new Font("SansSerif", Font.BOLD, 15));
        email.setForeground(Color.WHITE);
        email.setBounds(50, 100, 300, 30);
        gradientPanel.add(email);
        JTextField emailField = new JTextField();
        emailField.setBounds(50, 125, 300, 30);
        gradientPanel.add(emailField);

        // Contr
        JLabel contr = new JLabel("Contraseña");
        contr.setFont(new Font("SansSerif", Font.BOLD, 15));
        contr.setForeground(Color.WHITE);
        contr.setBounds(50, 170, 300, 30);
        gradientPanel.add(contr);
        JPasswordField passField = new JPasswordField();
        passField.setBounds(50, 195, 300, 30);
        gradientPanel.add(passField);

        // Botón
        JButton loginButton = new JButton("Iniciar Sesión");
        loginButton.setBounds(125, 240, 150, 35);
        gradientPanel.add(loginButton);

        // Texto alter
        JLabel altLoginLabel = new JLabel("O continuar con", SwingConstants.CENTER);
        altLoginLabel.setForeground(Color.WHITE);
        altLoginLabel.setBounds(100, 290, 200, 20);
        gradientPanel.add(altLoginLabel);

        // Escala íconos si son grandes
        Image googleImg = googleIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        Image githubImg = githubIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        Image facebookImg = facebookIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);

        // Crea botones con los íconos
        JButton googleBtn = new JButton(new ImageIcon(googleImg));
        googleBtn.setBounds(90, 320, 50, 50);
        googleBtn.setBorderPainted(false);
        googleBtn.setContentAreaFilled(false);
        gradientPanel.add(googleBtn);

        JButton githubBtn = new JButton(new ImageIcon(githubImg));
        githubBtn.setBounds(170, 320, 50, 50);
        githubBtn.setBorderPainted(false);
        githubBtn.setContentAreaFilled(false);
        gradientPanel.add(githubBtn);

        JButton facebookBtn = new JButton(new ImageIcon(facebookImg));
        facebookBtn.setBounds(250, 320, 50, 50);
        facebookBtn.setBorderPainted(false);
        facebookBtn.setContentAreaFilled(false);
        gradientPanel.add(facebookBtn);

        // Acción del botón
        loginButton.addActionListener(e -> {
            String usuario = emailField.getText().trim();
            String contraseña = new String(passField.getPassword()).trim();

            // Aquí puedes poner tu lógica de validación
            if (validarUsuario(usuario, contraseña)) {
                SwingUtilities.invokeLater(() -> new DunabInicio(usuario).setVisible(true));
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Método para validar contra archivo txt
    private boolean validarUsuario(String usuario, String contraseña) {
        try (BufferedReader br = new BufferedReader(new FileReader("Estru/usuarios.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 4) {
                    String user = partes[0].trim();
                    String pass = partes[2].trim();
                    if (usuario.equals(user) && contraseña.equals(pass)) {
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error leyendo archivo de usuarios", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
}