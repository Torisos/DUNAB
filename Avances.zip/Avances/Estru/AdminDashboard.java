import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class AdminDashboard extends JFrame {
    private String usuario;

    public AdminDashboard(String usuario) {
        this.usuario = usuario;
        setTitle("DUNAB - Panel Administrativo");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Barra superior
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.setBackground(new Color(0, 90, 255));
        JLabel title = new JLabel("Panel Administrativo");
        title.setFont(new Font("SansSerif", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        top.add(title);
        add(top, BorderLayout.NORTH);

        // Pestañas
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Usuarios", crearTabUsuarios());
        tabs.addTab("Eventos", crearTabEventos());
        add(tabs, BorderLayout.CENTER);
    }

    // -------- Usuarios --------
    private JPanel crearTabUsuarios() {
        JPanel panel = new JPanel(new BorderLayout());

        String[] cols = {"Usuario", "Celular", "Contraseña", "DUNAB"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return c != 0; } // usuario no editable
        };
        JTable table = new JTable(model);
        cargarUsuarios(model);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JButton agregar = new JButton("Agregar");
        JButton editar = new JButton("Guardar cambios");
        JButton eliminar = new JButton("Eliminar");

        acciones.add(agregar);
        acciones.add(editar);
        acciones.add(eliminar);

        // Agregar usuario
        agregar.addActionListener(e -> {
            JTextField u = new JTextField();
            JTextField cel = new JTextField();
            JTextField pass = new JTextField();
            JTextField dunab = new JTextField();
            Object[] msg = {"Usuario:", u, "Celular:", cel, "Contraseña:", pass, "DUNAB:", dunab};
            int ok = JOptionPane.showConfirmDialog(panel, msg, "Nuevo usuario", JOptionPane.OK_CANCEL_OPTION);
            if (ok == JOptionPane.OK_OPTION) {
                if (u.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(panel, "El usuario no puede estar vacío");
                    return;
                }
                model.addRow(new Object[]{u.getText().trim(), cel.getText().trim(), pass.getText().trim(), dunab.getText().trim()});
                guardarUsuarios(model);
            }
        });

        // Guardar cambios (ediciones en celdas)
        editar.addActionListener(e -> {
            guardarUsuarios(model);
            JOptionPane.showMessageDialog(panel, "Cambios guardados.");
        });

        // Eliminar usuario seleccionado
        eliminar.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                model.removeRow(row);
                guardarUsuarios(model);
            } else {
                JOptionPane.showMessageDialog(panel, "Selecciona un usuario para eliminar.");
            }
        });

        panel.add(acciones, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private void cargarUsuarios(DefaultTableModel model) {
        model.setRowCount(0);
        File f = new File("usuarios.txt"); // ajusta la ruta si usas carpeta Estru/
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                if (p.length == 4) {
                    model.addRow(new Object[]{p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim()});
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error leyendo usuarios.txt");
        }
    }

    private void guardarUsuarios(DefaultTableModel model) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("usuarios.txt"))) { // ajusta la ruta si usas carpeta Estru/
            for (int i = 0; i < model.getRowCount(); i++) {
                String u = String.valueOf(model.getValueAt(i, 0));
                String cel = String.valueOf(model.getValueAt(i, 1));
                String pass = String.valueOf(model.getValueAt(i, 2));
                String dunab = String.valueOf(model.getValueAt(i, 3)).replace(".", "").replace(",", "");
                pw.println(u + ";" + cel + ";" + pass + ";" + dunab);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error guardando usuarios.txt");
        }
    }

    // -------- Eventos --------
    private JPanel crearTabEventos() {
        JPanel panel = new JPanel(new BorderLayout());

        String[] cols = {"ID", "Título", "Fecha", "Lugar", "Descripción"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return true; }
        };
        JTable table = new JTable(model);
        cargarEventos(model);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JButton agregar = new JButton("Agregar");
        JButton guardar = new JButton("Guardar");
        JButton eliminar = new JButton("Eliminar");

        acciones.add(agregar);
        acciones.add(guardar);
        acciones.add(eliminar);

        agregar.addActionListener(e -> {
            JTextField id = new JTextField();
            JTextField titulo = new JTextField();
            JTextField fecha = new JTextField();
            JTextField lugar = new JTextField();
            JTextField desc = new JTextField();
            Object[] msg = {"ID:", id, "Título:", titulo, "Fecha (dd/MM/yyyy):", fecha, "Lugar:", lugar, "Descripción:", desc};
            int ok = JOptionPane.showConfirmDialog(panel, msg, "Nuevo evento", JOptionPane.OK_CANCEL_OPTION);
            if (ok == JOptionPane.OK_OPTION) {
                model.addRow(new Object[]{id.getText().trim(), titulo.getText().trim(), fecha.getText().trim(), lugar.getText().trim(), desc.getText().trim()});
                guardarEventos(model);
            }
        });

        guardar.addActionListener(e -> {
            guardarEventos(model);
            JOptionPane.showMessageDialog(panel, "Eventos guardados.");
        });

        eliminar.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                model.removeRow(row);
                guardarEventos(model);
            } else {
                JOptionPane.showMessageDialog(panel, "Selecciona un evento para eliminar.");
            }
        });

        panel.add(acciones, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private void cargarEventos(DefaultTableModel model) {
        model.setRowCount(0);
        File f = new File("eventos.txt"); // formato: id;titulo;fecha;lugar;descripcion
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                if (p.length == 5) {
                    model.addRow(new Object[]{p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim(), p[4].trim()});
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error leyendo eventos.txt");
        }
    }

    private void guardarEventos(DefaultTableModel model) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("eventos.txt"))) {
            for (int i = 0; i < model.getRowCount(); i++) {
                String id = String.valueOf(model.getValueAt(i, 0));
                String titulo = String.valueOf(model.getValueAt(i, 1));
                String fecha = String.valueOf(model.getValueAt(i, 2));
                String lugar = String.valueOf(model.getValueAt(i, 3));
                String desc = String.valueOf(model.getValueAt(i, 4));
                pw.println(id + ";" + titulo + ";" + fecha + ";" + lugar + ";" + desc);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error guardando eventos.txt");
        }
    }
}