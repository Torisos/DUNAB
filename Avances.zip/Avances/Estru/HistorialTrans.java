import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HistorialTrans extends JFrame{
    private String usuario;

    public HistorialTrans(String usuario){
        this.usuario = usuario;
        setTitle("DUNAB - Historial de Transacciones");
        setSize(900, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Panel gradiente
        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(0, 0, 102);
                Color color2 = new Color(0, 153, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setLayout(null);
        setContentPane(gradientPanel);

        // ICONOS
        ImageIcon dineroIcon = new ImageIcon("icons/dinero.png");
        ImageIcon perfilIcon = new ImageIcon("icons/perfil.png");
        ImageIcon transaccionIcon = new ImageIcon("icons/transacciones.png");

        // Escala íconos si son grandes
        Image dineroImg = dineroIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
        Image perfilImg = perfilIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);
        Image transaccionImg = transaccionIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH);

        // Barra superior
        JPanel topBar = new JPanel();
        topBar.setLayout(null);
        topBar.setBounds(0, 0, 900, 50);
        topBar.setBackground(new Color(0, 90, 255));
        gradientPanel.add(topBar);

        JButton title = new JButton("DUNAB");
        title.setFont(new Font("SansSerif", Font.BOLD, 15));
        title.setForeground(new Color(0, 90, 255));
        title.setBounds(20, 10, 100, 30);
        topBar.add(title);
        title.addActionListener(e -> new DunabInicio(usuario).setVisible(true));

        JLabel moneyIcon = new JLabel(new ImageIcon(dineroIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH)));
        moneyIcon.setBounds(120, 8, 40, 40);
        topBar.add(moneyIcon);

        JLabel perfilTop = new JLabel(new ImageIcon(perfilIcon.getImage().getScaledInstance(28, 28, Image.SCALE_SMOOTH)));
        perfilTop.setBounds(840, 10, 40, 40);
        topBar.add(perfilTop);

        // Texto principal
        JLabel historial = new JLabel("Historial de transacciones", SwingConstants.LEFT);
        historial.setFont(new Font("SansSerif", Font.BOLD, 25));
        historial.setForeground(Color.WHITE);
        historial.setBounds(0, 60, 900, 50);
        gradientPanel.add(historial);
        JLabel transIcon = new JLabel(new ImageIcon(transaccionImg));
        transIcon.setBounds(325, 75, 25, 25);
        gradientPanel.add(transIcon);

        // 🔹 Leer datos del archivo
        List<String> fechas = new ArrayList<>();
        List<String> tipos = new ArrayList<>();
        List<String> detalles = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("Estru/Trans.txt"))) {
            String linea;
            int x = 0;
            int f = 1;
            int t = 2;
            int d = 3;
            String user;
            String fecha;
            String tipo;
            String detalle;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(";");
                for (int i=0; i<=3; i++) {
                    if (x==0){
                        user = partes[0].trim();
                        fecha = partes[f].trim();
                        tipo = partes[t].trim();
                        detalle = partes[d].trim();
                        x+=1;
                    }else{
                        f+=3;
                        t+=3;
                        d+=3;
                        user = partes[0].trim();
                        fecha = partes[f].trim();
                        tipo = partes[t].trim();
                        detalle = partes[d].trim();
                    }

                    // Solo mostrar transacciones del usuario actual
                    if (user.equals(usuario)) {
                        fechas.add(fecha);
                        tipos.add(tipo);
                        detalles.add(detalle);
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error leyendo archivo de transacciones", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Panel de fechas
        JPanel panelFechas = crearPanelBlanco("Fechas", fechas.toArray(new String[0]));
        panelFechas.setBounds(50, 130, 200, 300);
        gradientPanel.add(panelFechas);

        // Panel de transacciones
        JPanel panelTransacciones = crearPanelBlanco("Transacciones", tipos.toArray(new String[0]));
        panelTransacciones.setBounds(350, 130, 200, 300);
        gradientPanel.add(panelTransacciones);

        // Panel de detalles
        JPanel panelDetalles = crearPanelBlanco("Detalles", detalles.toArray(new String[0]));
        panelDetalles.setBounds(650, 130, 200, 300);
        gradientPanel.add(panelDetalles);
        
        // Boton añadir
        JButton aña = new JButton("Añadir");
        aña.setBounds(700, 70, 150, 35);
        gradientPanel.add(aña);
        aña.addActionListener(e -> new AñadirHis(usuario).setVisible(true));

        // Botón Descargar PDF
        JButton descargarPDF = new JButton("Descargar PDF");
        descargarPDF.setBounds(540, 70, 150, 35);
        gradientPanel.add(descargarPDF);

        descargarPDF.addActionListener(e -> {
            try {
                generarPDFSimple(usuario);
                JOptionPane.showMessageDialog(this, "PDF generado correctamente");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error generando PDF");
            }
        });
    }

    private JPanel crearPanelBlanco(String titulo, String[] datos) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(titulo));
        for (String dato : datos) {
            JLabel label = new JLabel(dato);
            label.setFont(new Font("SansSerif", Font.PLAIN, 14));
            label.setAlignmentX(Component.CENTER_ALIGNMENT);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(label);
        }
        panel.setMaximumSize(new Dimension(450, panel.getPreferredSize().height));
        return panel;
    }

    // CREA UN "PDF" SIN LIBRERÍAS
    private void generarPDFSimple(String usuarioFiltro) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader("Estru/Trans.txt"));
             FileWriter fw = new FileWriter("Historial_" + usuarioFiltro + ".pdf")) {

            fw.write("HISTORIAL DE TRANSACCIONES\n");
            fw.write("Usuario: " + usuarioFiltro + "\n\n");

            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(";");

                if (!partes[0].trim().equals(usuarioFiltro)) continue;

                for (int i = 1; i + 2 < partes.length; i += 3) {
                    fw.write("Fecha: " + partes[i] + " | ");
                    fw.write("Tipo: " + partes[i + 1] + " | ");
                    fw.write("Detalle: " + partes[i + 2] + "\n");
                }
                fw.write("\n");
            }
        }
    }
}