import java.io.*;
import javax.swing.*;
import java.awt.*;

public class AñadirHis extends JFrame{
    private String usuario;

    public AñadirHis(String usuario){
        this.usuario = usuario;
        setTitle("Dunab - Nueva transaccion");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Panel gradiente
        JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(0, 0, 102);
                Color color2 = new Color(0, 153, 255);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        gradientPanel.setLayout(null);
        setContentPane(gradientPanel);

        JLabel añadir = new JLabel("Añadir transacciones", SwingConstants.LEFT);
        añadir.setFont(new Font("SansSerif", Font.BOLD, 25));
        añadir.setForeground(Color.WHITE);
        añadir.setBounds(0, 20, 900, 50);
        gradientPanel.add(añadir);

        // Campos para ingresar datos
        JLabel fech = new JLabel("Fecha", SwingConstants.LEFT);
        fech.setFont(new Font("SansSerif", Font.BOLD, 15));
        fech.setForeground(Color.WHITE);
        fech.setBounds(50, 150, 900, 50);
        gradientPanel.add(fech);
        JTextField fechaField = new JTextField();
        fechaField.setBounds(50, 190, 290, 30);
        gradientPanel.add(fechaField);
        
        JLabel tip = new JLabel("Tipo", SwingConstants.LEFT);
        tip.setFont(new Font("SansSerif", Font.BOLD, 15));
        tip.setForeground(Color.WHITE);
        tip.setBounds(50, 210, 900, 50);
        gradientPanel.add(tip);
        JTextField tipoField = new JTextField(); // Depósito o Retiro
        tipoField.setBounds(50, 250, 290, 30);
        gradientPanel.add(tipoField);

        JLabel deta = new JLabel("Detalles", SwingConstants.LEFT);
        deta.setFont(new Font("SansSerif", Font.BOLD, 15));
        deta.setForeground(Color.WHITE);
        deta.setBounds(50, 270, 900, 50);
        gradientPanel.add(deta);
        JTextField detalleField = new JTextField(); // Para quién / de quién
        detalleField.setBounds(50, 310, 290, 30);
        gradientPanel.add(detalleField);

        // Botón Guardar
        JButton guardarBtn = new JButton("Guardar Transacción");
        guardarBtn.setBounds(95, 370, 200, 40);
        gradientPanel.add(guardarBtn);

        guardarBtn.addActionListener(e -> {
            String fecha = fechaField.getText().trim();
            String tipo = tipoField.getText().trim();
            String detalle = detalleField.getText().trim();

            if (fecha.isEmpty() || tipo.isEmpty() || detalle.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor llena todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (FileWriter fw = new FileWriter("Estru/Trans.txt", true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {

                out.println(usuario + ";" + fecha + ";" + tipo + ";" + detalle);
                JOptionPane.showMessageDialog(this, "Transacción guardada exitosamente!");

                // Limpiar campos
                fechaField.setText("");
                tipoField.setText("");
                detalleField.setText("");

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar transacción", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });   
    }
}